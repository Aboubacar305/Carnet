<?php
require_once('libraries/Database.php');
require_once('libraries/Utiles.php'); 
require_once('libraries/models/Patient.php');

/** CE FICHIER A POUR BUT D'AFFICHER LA PAGE D'ACCUEIL !
 * a
 * On va donc se connecter à la base de données, récupérer les articles du plus récent au plus ancien (SELECT * FROM articles ORDER BY created_at DESC)
 * puis on va boucler dessus pour afficher schacun d'entre eux
 **/

/**
 * 1. Connexion à la base de données avec PDO
**/




$model=new Patient();
/**
* 2. Récupération des articles
* */

// On utilisera ici la méthode query (pas besoin de préparation car aucune variable n'entre en jeu)
$patients=$model->findAll();

/**
 * 3. Affichage
 */
 
 
$pageTitle = "Accueil";

render('patients/index',compact('pageTitle',
    'patients'));












  


