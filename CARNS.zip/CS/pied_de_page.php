<!-- LE PIED DE PAGE -->
<footer class="card-footer bg-transparent border-success bordure-footer">
<!-- L'en-tête du pied de page -->
    <div class="aligner_horizontal">
        <div>
            <p>Suivez nous sur :</p>
        </div>
        <div>
            <ul class="aligner_img_horizontal">
                <li><a href="#" class="enlever_trait"><img src="images/facebook.jpg"></a></li>
                <li><a href="#" class="enlever_trait"><img src="images/instagram.jpg"></a></li>
                <li><a href="#" class="enlever_trait"><img src="images/twitte.jpg"></a></li>
            </ul>
        </div>
    </div>
<!-- Le corps du pied de page -->
    <div class="aligner_2_blocks">
        <div>
            <p class="p_footer">En savoir plus</p>
            <ul class="enlever_puces_footer">
                <li class="marge_li"><a href="#" class="enlever_trait">Nous contacter</a></li>
                <li class="marge_li"><a href="#" class="enlever_trait">Siège social</a></li>
                <li class="marge_li"><a href="#" class="enlever_trait">Blog</a></li>
            </ul>
        </div>
        <div>
            <p class="p_footer">Règles</p>
            <ul class="enlever_puces_footer">
                <li class="marge_li"><a href="#" class="enlever_trait" class="couleur_li_footer">Règlement intérieur</a></li>
                <li class="marge_li"><a href="#" class="enlever_trait" class="couleur_li_footer">Principes</a></li>
                <li class="marge_li"><a href="#" class="enlever_trait" class="couleur_li_footer">Devoirs</a></li>
            </ul>
        </div>
    </div>
<!-- Le pied du pied de page -->
    <div class="pied-disposition">
        <img src="images/logo_pied.png" alt="logo pied de page" class="logo_pied">
        <div>
            <ul class="puces_footer">
                <li class="marge_li"><a href="#" class="enlever_trait">Aide</a></li>
                <li class="marge_li"><a href="#" class="enlever_trait">Confidentialité</a></li>
            </ul>
        </div>
    </div>
</footer>







