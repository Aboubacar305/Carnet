

<!-- En-tête de la page -->
<img src="images/toto.jpg" class="img-fluid bordure-entete" alt="Responsive image">

