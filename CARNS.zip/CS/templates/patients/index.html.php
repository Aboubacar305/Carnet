



<h1>Liste des patients</h1>

     
<?php $i=1; ?>
<table>
      <thead>
      
            <th>Numero </th>
            <th>Nom</th>
            <th>Prenom</th>
            <th>Genre</th>
            <th>Profession</th>
            <th>Date_naissance</th>
            <th>Groupe Sanguin</th>
            <th>Telephone</th>
            <th>Detail</th>
            <th>Supprimer</th>
      </thead>
      <tbody>
<?php foreach ($patients as $patient) : ?>
    <tr>
            <td> <?php echo ' [   '. $i++.'    ]'; ?></td>
            <td> <?= $patient['nom'] ?></td>
            <td> <?= $patient['prenom'] ?></td>
            <td> <?= $patient['genre'] ?></td>
            <td> <?= $patient['profession'] ?></td>
            <td> <?= $patient['date_naiss'] ?></td>
            <td> <?= $patient['group_sang'] ?></td>
            <td> <?= $patient['telephone'] ?></td>
            <td><a href="patient.php?id=<?= $patient['id'] ?>">DETAILS</a></td>
            <td><a href="delete-patient.php?id=<?= $patient['id'] ?>" onclick="return window.confirm(`Êtes vous sur de vouloir supprimer ce patient ?!`)">DELETE</a></td>
    </tr>
   
    
      

<?php endforeach ?>
</tbody>
</table>




 









