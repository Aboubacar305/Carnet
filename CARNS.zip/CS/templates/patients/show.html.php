


<h1><?= $patient['nom'] ?></h1>

<h1><?= $patient['prenom'] ?></h1>

<small>Ecrit le <?= $patient['created_at'] ?></small>
<p><?= $patient['genre'] ?></p>

<p><?= $patient['profession'] ?></p>

<hr>

 

<?php if (count($consultations) === 0) : ?>
    <h2>Il n'y a pas encore de consultations pour <?= $patient['nom'] ?>  <?= $patient['prenom'] ?></h2>

<?php else: ?>
<h1>Consultation de <?= $patient['nom'] ?>  <?= $patient['prenom'] ?></h1>

     
<?php $i=1; ?>
<table>
      <thead>
      
            <th>Numero </th>
            <th>Date</th>
            <th>Poids</th>
            <th>Tension</th>
            <th>Temperature</th>
            <th>Debut maladie</th>
            <th>Symptomes</th>
            <th>Traitement en cours</th>
            <th>Commentaire</th>
            <th>Supprimer</th>
      </thead>
      <tbody>
<?php foreach ($consultations as $consultation) : ?>
    <tr>
            <td> <?php echo ' [   '. $i++.'    ]'; ?></td>
            <td> <?= $consultation['date'] ?></td>
            <td> <?= $consultation['poids'] ?></td>
            <td> <?= $consultation['tension'] ?></td>
            <td> <?= $consultation['temp'] ?></td>
            <td> <?= $consultation['debut'] ?></td>
            <td> <?= $consultation['symptomes'] ?></td>
            <td> <?= $consultation['trait_cours'] ?></td>
            <td> <?= $consultation['prescri'] ?></td>
            <td> <?= $consultation['comment'] ?></td>
            <td><a href="delete-consultation.php?id=<?=$consultation['id'] ?>" onclick="return window.confirm(`Êtes vous sur de vouloir supprimer cette consultaion ?!`)">Supprimer</a></td>
    </tr>
<?php endforeach ?>
</tbody>
</table>





<?php endif ?>






<form action="save-consultation.php" method="POST">
    <input type="hidden" name="date" value="NOW()">
    <input type="text" name="poids"placeholder="Poids du Patient">
    <input type="text" name="temp" placeholder="Temperature en celcus">
    <input type="text" name="tension" placeholder="Tension">
    <input type="date" name="debut" placeholder="Debut de la maladie">
    <input type="text" name="symptomes" placeholder="Symptomes de la maladie">
    <input type="text" name="trait_cours" placeholder="Traitement en cours">
    <input type="text" name="prescri" placeholder="Prescription donnée">
    <input type="text" name="comment" placeholder="Commentaires">

</form>