<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Mon superbe blog - <?= $pageTitle ?></title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="style.css">
</head>

<body>
<?php
            include("en_tete.php");
        ?>
    <?= $pageContent ?>


                






                </div>
                <div class="col-md-4 bordure-cadre-menu">
                    <div class="logo">
                        <img src="images/logo.png" class="card-img-top logo" alt="...">
                    </div>
                    <div class="card-body">
                        <a type="button" class="btn btn-primary btn-lg btn-block" href="index.php">Accueil</a>
                        <a type="button" class="btn btn-secondary btn-lg btn-block mt-5" href="Enregistrer_patient.php">Enregistrer un patient</a>
                        <a type="button" class="btn btn-info btn-lg btn-block mt-5 mb-5" href="Afficher_liste_des_patients.php">Afficher la liste des patients</a>
                    </div>
                </div>
            </div>
        </div>





    <div>
            <?php
                include("pied_de_page.php");
            ?>
        </div>

    <script src="js/popper.js"></script>
        <script src="js/jquery.slim.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
</body>

</html>