<form class="mt-5" method="post" action="mes_patients.php" name="FormulairePatient">
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Image d'en-tête</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="style.css">
    </head>
    <body>

        <!-- En-tête de la page -->
        <?php
            include("en_tete.php");
        ?>


        <!-- Menu -->
        <div class="card mb-3 bordure-cadre-principal" style="max-width: 100%;">
            <div class="row no-gutters alignement">
                <div class="col-md-8 marges">
                
                    <h1>BIENVENUE A LA CLINIQUE HALLO DOCTEUR</h1>
                    <p>Cette plateforme est un <strong>carnet de santé numérique</strong> permettant de faciliter la consultation et une meilleure prise en charge des patients.</p>

                    <div class="sous-bloc mt-5">
                        <div class="card text-white bg-secondary mb-3" style="max-width: 18rem;">
                            <div class="card-header" style="text-align: center;"><h5>Enregistrer un patient</h5></div>
                            <div class="card-body">
                                <p class="card-text">Cette section vous permet de vous enregistrer en tant que patient par le remplissage d'un formulaire.</p>
                                <p>Veuillez fournir des informations précises afin que nous puissions vous apporter toute l'aide nécessaire.</p>
                            </div>
                        </div>

                        <div class="card text-white bg-info mb-3" style="max-width: 18rem;">
                            <div class="card-header" style="text-align: center;"><h5>Afficher la liste des patients</h5></div>
                            <div class="card-body">
                                <p class="card-text">Cette section vous permet de consulter la liste de nos patients et d'accéder aussi aux détails des informations sanitaires. Vous pouvez également modifier ou supprimer les informations recueillies.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 bordure-cadre-menu">
                    <div class="logo">
                        <img src="images/logo.png" class="card-img-top logo" alt="...">
                    </div>
                    <div class="card-body">
                        <a type="button" class="btn btn-primary btn-lg btn-block " href="index.php">Accueil</a>
                        <a type="button" class="btn btn-secondary btn-lg btn-block mt-5" href="Enregistrer_patient.php">Enregistrer un patient</a>
                        <a type="button" class="btn btn-info btn-lg btn-block mt-5 mb-5" href="liste.php">Afficher la liste des patients</a>
                    </div>
                </div>
            </div>
        </div>



        <!-- Pied de page -->
        <div>
            <?php
                include("pied_de_page.php");
            ?>
        </div>

        
        
        


        <script src="js/popper.js"></script>
        <script src="js/jquery.slim.min.js"></script>
        <script src="js/bootstrap.min.js"></script>






    </body>

</html>