<?php
require_once('libraries/Database.php');
require_once('libraries/Utiles.php');
require_once('libraries/models/Patient.php');
/**
 * DANS CE FICHIER, ON CHERCHE A SUPPRIMER L'ARTICLE DONT L'ID EST PASSE EN GET
 * 
 * Il va donc falloir bien s'assurer qu'un paramètre "id" est bien passé en GET, puis que cet article existe bel et bien
 * Ensuite, on va pouvoir effectivement supprimer l'article et rediriger vers la page d'accueil
 */

/**
 * 1. On vérifie que le GET possède bien un paramètre "id" (delete.php?id=202) et que c'est bien un nombre
 */
if (empty($_GET['id']) || !ctype_digit($_GET['id'])) {
    die("id du patient introuvable!  veuillez preciser le id du patient");
}

$id = $_GET['id'];

/**
 * 2. Connexion à la base de données avec PDO
**/



$model=new Patient();






/**
 * 3. Vérification que l'article existe bel et bien
 */
$patient=$model->find($id);

if (!$patient) {
    die("Le patient $id n'existe pas, vous ne pouvez donc pas le supprimer !");
}

/**
 * 4. Réelle suppression de l'article
 */
$model->delete($id); 
/**
 * 5. Redirection vers la page d'accueil
 */
redirect("accueil.php");

