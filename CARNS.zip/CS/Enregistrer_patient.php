<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Image d'en-tête</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="style.css">
    </head>
    <body>

        <!-- En-tête de la page -->
        <?php
            include("en_tete.php");
        ?>


        <!-- Menu -->
        <div class="card mb-3 bordure-cadre-principal" style="max-width: 100%;">
            <div class="row no-gutters alignement">
                <div class="col-md-8 marges">

                    <div class="bordure-cadre">
                        <h1 class="centrer">FICHE MEDICALE</h1>
                    </div>

                    <form class="mt-5" method="post" action="mes_patients.php" name="FormulairePatient">
                        <div class="form-group row">
                            <label for="nom" class="col-sm-4 col-form-label">Nom</label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control" id="nom" name="nom">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="prenom" class="col-sm-4 col-form-label">Prenom</label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control" id="prenom" name="prenom">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="sexe" class="col-sm-4 col-form-label">Sexe</label>
                            <select class="form-control col-sm-5 ml-3" id="sexe" name="selection05" required>
                                <option selected value="masculin">Masculin</option>
                                <option selected value="feminin">Féminin</option>
                            </select>
                        </div>
                        <div class="form-group row">
                            <label for="telephone" class="col-sm-4 col-form-label">N° Téléphone</label>
                            <div class="col-sm-6">
                                <input type="tel" class="form-control" id="telephone" name="telephone">
                            </div>
                        </div>
                    
                        <div class="form-group row horizontale">
                            <label for="date_naissance" class="col-sm-4 col-form-label">Date de naissance</label>
                            <div class="col-sm-6">
                                <input type="date" class="form-control" id="date_naissance" name="naissance">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="adresse_domicile" class="col-sm-4 col-form-label">Adresse domicile</label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control" id="adresse_domicile" name="adresse">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="maladie" class="col-sm-4 col-form-label">Quel est votre problème de santé ?</label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control" id="maladie" name="psante">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="commentaire" class="col-sm-4 col-form-label">Y-a-t-il des probèmes médicaux dans votre famille ?</label><br>
                            <div class="col-sm-6">
                                <textarea type="text" class="form-control" id="commentaire" name="antecedents"></textarea>
                            </div>
                        </div>


                        <input type="submit" value="Enregistrer" href="database.php">




                    </form>



                </div>
                <div class="col-md-4 bordure-cadre-menu">
                    <div class="logo">
                        <img src="images/logo.png" class="card-img-top logo" alt="...">
                    </div>
                    <div class="card-body">
                        <a type="button" class="btn btn-primary btn-lg btn-block" href="index.php">Accueil</a>
                        <a type="button" class="btn btn-secondary btn-lg btn-block mt-5" href="Enregistrer_patient.php">Enregistrer un patient</a>
                        <a type="button" class="btn btn-info btn-lg btn-block mt-5 mb-5" href="Afficher_liste_des_patients.php">Afficher la liste des patients</a>
                    </div>
                </div>
            </div>
        </div>



        <!-- Pied de page -->
        <div>
            <?php
                include("pied_de_page.php");
            ?>
        </div>

        
        
        


        <script src="js/popper.js"></script>
        <script src="js/jquery.slim.min.js"></script>
        <script src="js/bootstrap.min.js"></script>






    </body>

</html>