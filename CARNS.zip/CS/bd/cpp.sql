--
-- MySQL 5.5.5
-- Wed, 08 Apr 2020 13:33:36 +0000
--

create database CS;

use CS;




CREATE TABLE `antecedent` (
   `id` int(11) not null auto_increment,
   `id_patient` int(11) not null,
   `allergie` text not null,
   `vaccin` text not null,
   `chirurgie` text not null,
   `examen` text not null,
   PRIMARY KEY (`id`),
   KEY `FK_PATIENTS` (`id_patient`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1;

CREATE TABLE `patients` (
   `id` int(11) not null auto_increment,
   `nom` varchar(255) not null,
   `prenom` varchar(255) not null,
   `genre` varchar(255) not null,
   `profession` varchar(255) not null,
   `group_sang` varchar(255) not null,
   `date_naiss` date not null,
   `telephone` int(15) not null,
   PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1;
