<?php


/**
 * function De rendu
 * */
 
 function render(string $path, array $variables=[]){
   //a chaque fois que j'ai le tableau associatif suivant
   //['var1'=>2]
   // qu'il y'a réellement après transformation une variables
   //$var1 =2;
   
   extract($variables);
   

ob_start();
require('templates/'.$path.'.html.php');
$pageContent = ob_get_clean();

require('templates/layout.html.php');
   
 }
 
 
 //fonction de redirection de la page
 
 
 function redirect(string $url){
   header('Location: '.$url);
   exit();
   
   
   

 }