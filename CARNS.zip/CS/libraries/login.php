<?php
require_once('libraries/Database.php');
 function verif()
{
$bd= getpdo();
if(isset($_POST['email']) AND isset($_POST['pwd']))
{
    $email=htmlspecialchars($_POST['email']);
    $pwd=htmlspecialchars($_POST['pwd']);
        $del=$bd->prepare('DELETE FROM session');
        $del->execute();
        $requette =$bd->prepare('SELECT * FROM medecin WHERE email =:email AND pwd =:pwd ');
        $requette->execute(array('email'=>$email, 'pwd'=>$pwd));
        $resp=$requette->fetch();
        if($resp)
        {            
              $id=$resp['id'];
              $rek=$bd->prepare("INSERT INTO session SET id={$id}");
              $rek->execute();
            return 'ok';
        }
        else
        {
            $erreur="mot de passe ou nom d'utilisateur incorect";
            return $erreur;
        }
}    
}




