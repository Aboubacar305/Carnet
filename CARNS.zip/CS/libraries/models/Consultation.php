<?php

require_once('libraries/models/Model.php');

class Consultation extends Model{
      
      

      
   protected $table="consultations";
      
      
      

      
    public function findAllByPatient($id_patient):array{
      
 $query = $this->pdo->prepare("SELECT * FROM consultations WHERE id_patient = :id_patient");
$query->execute(['id_patient' => $id_patient]);
$consultations = $query->fetchAll();

      
      return $consultations;
}


   

 
      

public function insert($author,$content,$article_id){
         
        $query = $this->pdo->prepare('INSERT INTO consultations SET author = :author, content = :content, article_id = :article_id, created_at = NOW()');
        $query->execute(compact('author', 'content', 'article_id'));  
          
    }
      
      
      
}