<?php



require_once('libraries/models/Model.php');
class Patient extends Model{
      
      protected $table="patients";
       
}