<?php






require_once('libraries/models/Model.php');

class Medecin extends Model{
     protected $table='medecin';
}